var quotes =[
    '"The greatest glory in living lies not in never falling, but in rising every time we fall." <br/>-Nelson Mandela',
    '"The way to get started is to quit talking and begin doing." <br/>- Walt Disney',
    '"Your time is limited, so don\'t waste it living someone else\'s life. Don\'t be trapped by dogma – which is living with the results of other people\'s thinking." <br/>-Steve Jobs',
    '"If life were predictable it would cease to be life, and be without flavor."<br/>-Eleanor Roosevelt',
    '"If you look at what you have in life, you\'ll always have more. If you look at what you don\'t have in life, you\'ll never have enough."<br/>-Oprah Winfrey',
    '"If you set your goals ridiculously high and it\'s a failure, you will fail above everyone else\'s success."<br/>-James Cameron',
    '"Don\’t take rest after your first victory because if you fail in second, more lips are waiting to say that your first victory was just luck.”<br/> APJ Abdul Kalam-',
    '"Life is what happens when your busy making other plans."<br/> -John Lennon',
    '"The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart."<br/> -Helen Keller',
     '"It is during our darkest moments that we must focus to see the light."<br/> -Aristotle',
     '"Whoever is happy will make others happy too."<br/> -Anne Frank',
     '"A rose by any other name would smell as sweet."<br/> -William Shakespeare',
     '"Ask, and it shall be given you; seek, and you shall find."<br/>-Bible',
     '"If at first you don’t succeed, try, try again."</br/> -	W. E. Hickson',
     '"The most beautiful people we have known are those who have known defeat, known suffering, known struggle, known loss, and have found their way out of those depths."<br/>-Elisabeth Kubler-Ross',
     '"Forty Wall Street is probably the most beautiful tower in New York."<br/>-Donald Trump',
     '"Dream, dream, dream. Dreams transform into thoughts and thoughts result in action."<br/> -APJ Abdul Kalam',
    ]
    function NewQuote(){
        var rno = Math.floor(Math.random() * (quotes . length));
        document.getElementById('QuoteDisplay').innerHTML = quotes[rno];
    }